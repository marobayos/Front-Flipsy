import React from 'react';
import './App.css';
import Registro from "./componentes/Registro";

function App() {
  return (
    <div className="App">
        <Registro/>
    </div>
  );
}

export default App;
